Modify the below code to remove the list structure from the file and
seperate each element from the list via a "comma"

json_list = [
  {
    "Indentity": "dummy1",
    "ShapeMode": "ADD",
    "KeyValue": "99999999",
    "ShapeLines": [
      {
        "Caption": "ShapeMode",
        "value": "ADD"
      },
      {
        "Caption": "KeyValue",
        "value": ""
      },
      {
        "Caption": "Link to Person",
        "value": "99999999"
      }
    ],
    "SubData": []
  },
  {
    "Indentity": "dummy1",
    "ShapeMode": "ADD",
    "KeyValue": "99999999",
    "ShapeLines": [
      {
        "Caption": "ShapeMode",
        "value": "ADD"
      },
      {
        "Caption": "KeyValue",
        "value": "12"
      },
      {
        "Caption": "Link to Person",
        "value": "99999999"
      }
    ],
    "SubData": []
  }
]

grouped_records = {}
for record in json_list:
  key = record['KeyValue']
  if key not in grouped_records:
     grouped_records[key] = [record]
  else:
     grouped_records[key].append(record)


# for key_value, records in grouped_records.items():
#     file_name = f"{key_value}.json"
#     with open(file_name, "w") as json_file:
#        json.dump(records, json_file, indent=2)
        
for key_value, records in grouped_records.items():
    file_name = f"{key_value}.json"
    with open(file_name, "w") as json_file:
        # Write each record with a comma after it (except for the last one)
        for i, record in enumerate(records):
            json.dump(record, json_file, indent=2)
            if i < len(records) - 1:
                json_file.write(',')
            # Add a newline between records for better readability
            json_file.write('\n')