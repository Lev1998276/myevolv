import requests
import boto3
import json
import time
import os

# Function to check the validity of the token
def is_token_valid(token):
    # Add logic to check the validity of the token (e.g., check expiration)
    # Example: Assume the token is valid for 60 seconds
    current_time = time.time()
    token_creation_time = float(token.split("_")[1])  # Assuming the token has a format like "TOKEN_TIMESTAMP"
    expiration_time = token_creation_time + 60  # Token is valid for 60 seconds

    return current_time < expiration_time

# Function to obtain a new access token
def obtain_new_access_token():
    # Add logic to obtain a new access token using the required format
    # Example: Assume obtaining a new token involves making an API request
    # to a token endpoint and extracting the new token from the response
    token_endpoint = "your_token_endpoint_here"
    
    # Make a request to the token endpoint and extract the new token
    response = requests.post(token_endpoint, data={"grant_type": "client_credentials", "client_id": "your_client_id", "client_secret": "your_client_secret"})
    
    if response.status_code == 200:
        new_access_token = response.json().get('access_token')
        return new_access_token
    else:
        # Handle the case when obtaining a new token fails
        print(f"Failed to obtain a new access token. Response: {response.text}")
        return None

# Function to get access token
def get_access_token():
    # Add logic to obtain access token using the required format
    # Example: access_token = obtain_access_token_from_somewhere()
    access_token = "your_access_token_here"
    
    # Check if the token is valid (for example, check expiration)
    if is_token_valid(access_token):
        return access_token
    else:
        # If the token is not valid, obtain a new one
        new_access_token = obtain_new_access_token()
        return new_access_token

# Function to post JSON data to API
def post_data_to_api(data, headers):
    api_url = "your_api_url_here"
    response = requests.post(api_url, data=json.dumps(data), headers=headers)
    return response

# Function to move file to COMPLETED_FOLDER in S3
def move_to_completed_folder(file_key, s3_bucket, completed_folder):
    s3 = boto3.client('s3')
    copy_source = {'Bucket': s3_bucket, 'Key': file_key}
    s3.copy_object(Bucket=s3_bucket, CopySource=copy_source, Key=f"{completed_folder}/{file_key}")
    s3.delete_object(Bucket=s3_bucket, Key=file_key)

# Helper function to get a list of files from S3
def get_list_of_files_from_s3(s3_bucket, folder):
    s3 = boto3.client('s3')
    response = s3.list_objects_v2(Bucket=s3_bucket, Prefix=folder)

    files = [obj['Key'] for obj in response.get('Contents', [])]
    return files

# Main function
def main():
    s3_bucket = "your_s3_bucket_here"
    source_folder = "source_folder"
    completed_folder = "COMPLETED_FOLDER"

    headers = {
        'Content-Type': 'application/json',
        'Accept': '*/*'
    }

    for file_key in get_list_of_files_from_s3(s3_bucket, source_folder):
        access_token = get_access_token()
        headers['token'] = access_token

        with open(file_key, 'r') as file:
            json_data = json.load(file)

        response = post_data_to_api(json_data, headers)

        if response.status_code == 200:
            move_to_completed_folder(file_key, s3_bucket, completed_folder)
        else:
            print(f"Failed to post data for {file_key}. Response: {response.text}")

        # Sleep for 60 seconds
        time.sleep(60)

if __name__ == "__main__":
    main()
