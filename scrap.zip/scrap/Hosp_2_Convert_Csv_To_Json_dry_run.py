import os
import snowflake.connector
import boto3
from botocore.exceptions import ClientError
import pandas as pd
import csv
import json
import configparser
from datetime import datetime


s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')

CEDL_HOME = os.environ['CEDL_HOME']
nexus_connectionProfile = CEDL_HOME + '/etc/.sf.nexus.profile'
s3_connectionProfile = CEDL_HOME + '/etc/.s3_connection_profile'


def read_config(file_path='config.ini'):
    config = configparser.ConfigParser()
    config.read(file_path)
    return config


def read_csv_from_s3(bucket_name, file_key):
    s3 = boto3.client('s3')
    local_file = 'hospitalization.csv'
    s3.download_file(bucket_name, file_key, local_file)
    csv_data = []
    with open(local_file, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        header = next(csv_reader)
        for row in csv_reader:
            row_dict = {header[i]: value for i, value in enumerate(row)}
            csv_data.append(row_dict)
    return csv_data


def convert_row_to_json(row):
    admission_date = datetime.strptime(row['Admission Date'], '%Y-%m-%d %I:%M %p').strftime('%m/%d/%Y %I:%M %p')
    column_names = row.keys()
    #form_lines = [{"Caption": column, "value": row[column]} for column in column_names]
    form_lines = [{"Caption": column, "value": row[column]} for column in column_names if column not in ['AutomationKey','FormMode','KeyValue']]
    json_data = {
        "AutomationKey": row['AutomationKey'],
        "FormMode": row['FormMode'],
        "KeyValue": row['KeyValue'],
        "FormLines": form_lines,
        "SubData": []
    }
    return json_data



def list_json_files_in_folder(folder_path):
    return [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f)) and f.endswith('.json')]


def upload_files_to_s3(bucket_name, local_folder, archive_folder):
    s3 = boto3.client('s3')
    json_files_to_upload = list_json_files_in_folder(local_folder)
    for file_name in json_files_to_upload:
        local_file_path = os.path.join(local_folder, file_name)
        s3_object_key = file_name
        s3.upload_file(local_file_path, bucket_name, s3_object_key)
        archive_object_key = os.path.join(archive_folder, file_name)
        s3.upload_file(local_file_path, bucket_name, archive_object_key)
        print(f"File '{file_name}' uploaded to S3 and archived.")



if __name__ == "__main__":

config = read_config()

# Access values from the configuration
local_file_path = config.get('Hospitalization', 'local_file_path')
s3_bucket_name = config.get('Hospitalization', 's3_bucket_name')
s3_key = config.get('Hospitalization', 's3_key')
s3_folder = config.get('Hospitalization', 's3_folder')
s3_archive_folder = config.get('Hospitalization', 's3_archive_folder')
csv_file_path = config.get('Hospitalization', 'csv_file_path')


csv_data = read_csv_from_s3(s3_bucket_name, s3_key)


for row in csv_data:
    print(row)

json_list = [convert_row_to_json(record) for record in csv_data]


for record in json_list:
    print(json.dumps(record, indent = 4))


grouped_records = {}
for record in json_list:
  key = record['KeyValue']
  if key not in grouped_records:
    grouped_records[key] = [record]
  else:
    grouped_records[key].append(record)



######################### NEW CODE TO ADD ALL RECORDS / KEYS TO SEPARATE FILES #################################3       


import json
import time

# Create a filename with timestamp
#timestamp = time.strftime("%Y%m%d%H%M%S")
file_name = "Json_records.json"


#file_name = f"Json_records_{timestamp}.json"
delimiter = chr(31)
file_name = "Json_records.json"
with open(file_name, "w") as json_file:
   for key_value, records in grouped_records.items():
        # Write each record with a comma after it (except for the last one)
        for i, record in enumerate(records):
            json.dump(record, json_file, indent=2)
            json_file.write(delimiter)
            # Add a newline between records for better readability
            json_file.write('\n')

    
            
 # Create a file for key_value
 #key_value_file_name = f"Json_Keys_{timestamp}.csv"
 
key_value_file_name = "Json_Keys.csv" 
with open(key_value_file_name, "w", newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['key_value'])
    for key_value in grouped_records.keys():
        csv_writer.writerow([key_value])
        
        
        
  
      
### can be in post api script ################/
      
file_name = "Json_records.json" 
delimiter = chr(31)
with open(file_name, "r") as json_file:
    content = json_file.read()

# Split the content based on the delimiter
records = content.split(delimiter)


# Remove empty entries in case there are extra delimiters
records = [record.strip() for record in records if record.strip()]

for i, record in enumerate(records):
    try:
        data = json.loads(record)
        print(f"Record {i + 1}: {data}")
    except json.JSONDecodeError as e:
        print(f"Error decoding record {i + 1}: {e}")