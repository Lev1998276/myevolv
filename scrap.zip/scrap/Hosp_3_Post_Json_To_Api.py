import requests
import boto3
import json
import time

# Set your API endpoint and S3 bucket details
api_url = "https://example.com/api"  # Replace with your API endpoint
s3_bucket_name = "your-s3-bucket-name"
completed_folder = "completed"

# Set your AWS credentials
aws_access_key_id = "your-access-key-id"
aws_secret_access_key = "your-secret-access-key"
aws_region = "your-aws-region"

# Audit log file
audit_log_file = "audit_log.txt"

# Maximum number of retry attempts for API timeout
max_retries = 3

# Function to fetch JSON data from S3
def get_json_data_from_s3(key):
    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=aws_region)
    obj = s3.get_object(Bucket=s3_bucket_name, Key=key)
    return json.load(obj['Body'])

# Function to post JSON data to the API with timeout handling
def post_json_data_to_api(json_data):
    retries = 0
    while retries < max_retries:
        try:
            response = requests.post(api_url, json=json_data, timeout=60)
            response.raise_for_status()
            print(f"Data posted successfully: {response.json()}")
            return True
        except requests.exceptions.Timeout:
            retries += 1
            print(f"Request timed out. Retrying... (Attempt {retries}/{max_retries})")
            time.sleep(60)  # Wait for 60 seconds before retrying
        except requests.exceptions.RequestException as e:
            print(f"Error posting data: {e}")
            return False
    print(f"Max retries reached. Failed to post data after {max_retries} attempts.")
    return False

# Function to move processed file to 'completed' folder in S3
def move_to_completed_folder(key):
    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=aws_region)
    new_key = f"{completed_folder}/{key}"
    s3.copy_object(Bucket=s3_bucket_name, CopySource={'Bucket': s3_bucket_name, 'Key': key}, Key=new_key)
    s3.delete_object(Bucket=s3_bucket_name, Key=key)

# Function to log processed files in the audit log
def log_audit(file_name, success):
    with open(audit_log_file, 'a') as log_file:
        log_file.write(f"{file_name} - {'Success' if success else 'Failed'}\n")

# Function to process all JSON files from S3 bucket
def process_all_files():
    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=aws_region)
    response = s3.list_objects_v2(Bucket=s3_bucket_name)
    
    for obj in response.get('Contents', []):
        key = obj['Key']
        json_data = get_json_data_from_s3(key)
        success = post_json_data_to_api(json_data)
        
        if success:
            move_to_completed_folder(key)
        
        log_audit(key, success)
        time.sleep(60)  # Pause for 60 seconds before the next request

# Start processing files
process_all_files()
