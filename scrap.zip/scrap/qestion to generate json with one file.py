Instead of generating a new file for each key_value I want all
the contents of the dictionary with the records in one file name in one file name "records_timestamp".json
and 'key_value' in another file name "key_value_timestamp.csv" modify the following code to do so "

for key_value, records in grouped_records.items():
    file_name = f"{key_value}.json"
    with open(file_name, "w") as json_file:
        # Write each record with a comma after it (except for the last one)
        for i, record in enumerate(records):
            json.dump(record, json_file, indent=2)
            if i < len(records) - 1:
                json_file.write(',')
            # Add a newline between records for better readability
            json_file.write('\n')
"

import json
import time

grouped_records = {
    "key1": [{"name": "John", "age": 25}, {"name": "Alice", "age": 30}],
    "key2": [{"name": "Bob", "age": 22}, {"name": "Eve", "age": 28}]
}

# Create a filename with timestamp
timestamp = time.strftime("%Y%m%d%H%M%S")
file_name = f"filename_{timestamp}.json"

with open(file_name, "w") as json_file:
    # Write each record with a comma after it (except for the last one)
    for key_value, records in grouped_records.items():
        json.dump({key_value: records}, json_file, indent=2)
        # Add a newline between records for better readability
        json_file.write('\n')



import json

# Replace 'filename_timestamp.json' with the actual filename you used
file_name = 'filename_20240206060523.json'

with open(file_name, 'r') as json_file:
    data = json.load(json_file)

# Now 'data' contains the contents of the JSON file
print(data)


#################


# Create a filename with timestamp
timestamp = time.strftime("%Y%m%d%H%M%S")
file_name = f"Json_records_{timestamp}.json"

with open(file_name, "w") as json_file:
   for key_value, records in grouped_records.items():
        # Write each record with a comma after it (except for the last one)
        for i, record in enumerate(records):
            json.dump(record, json_file, indent=2)
            json_file.write('#')
            # Add a newline between records for better readability
            json_file.write('\n')
            
            
 # Create a file for key_value
key_value_file_name = f"Json_Keys_{timestamp}.csv"
with open(key_value_file_name, "w", newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['key_value'])
    for key_value in grouped_records.keys():
        csv_writer.writerow([key_value])
  
  
  
  
delimiter = chr(31)
timestamp = time.strftime("%Y%m%d%H%M%S")
file_name = f"Json_records_{timestamp}.json"
with open(file_name, "w") as json_file:
   for key_value, records in grouped_records.items():
        # Write each record with a comma after it (except for the last one)
        for i, record in enumerate(records):
            json.dump(record, json_file, indent=2)
            json_file.write(delimiter)
            # Add a newline between records for better readability
            json_file.write('\n')