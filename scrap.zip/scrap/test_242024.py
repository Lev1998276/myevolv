import csv
csv_data = []
csv_file_path = '/AppDev/CEDL/etl/SrcFiles/lg/myevolve/output1.csv'



json_data = {
    "AutomationKey": row['AutomationKey'],
    "FormMode": row['FormMode'],
    "KeyValue": row['KeyValue'],
    "FormLines": form_lines,
    "SubData": []
}


csv_data = [] 
with open(csv_file_path, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    # Get the header from the first row
    header = next(csv_reader)
    # Iterate through rows and create dictionaries
    for row in csv_reader:
        row_dict = {header[i]: value for i, value in enumerate(row)}
        csv_data.append(row_dict)



grouped = {}
for record in csv_data:
  key = record['KeyValue']
  if key not in grouped:
    grouped[key] = [record]
  else:
    grouped[key].append(record)
    

from collections import defaultdict
form_lines = defaultdict(list)

for key, record  in grouped.items():
    temp = []
    file_name = f"{key}.json"
    for row in record:
      column_names = row.keys()
      temp = [{"Caption": column, "value": row[column]} for column in column_names]
      form_lines[key].extend(temp)


for k, v in form_lines.items():
    print(json.dumps(v, indent = 4))
    