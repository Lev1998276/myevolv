HOW TO KEEP TRACK OF EACH RECORD POSTED TO THE API , RECORDS ONCE POSTED CANNOT BE RESPOSTED,
# ALSO IF PROCESS NEEDS TO BE RESTARTED THEN ONLY RECORDS THAT WERE NOT POSTED MUST BE POSTED .
# GIVE ME THE CODE TO DO SO

import requests
import json
import os

def post_to_api(record):
    # Example function to post the record to the API
    # Replace this with your actual API posting logic
    api_url = "your_api_endpoint"
    response = requests.post(api_url, data=json.dumps(record), headers={'Content-Type': 'application/json'})
    if response.status_code == 200:
        return True
    else:
        return False

def main():
    records = [
        {"id": 1, "data": "Record 1"},
        {"id": 2, "data": "Record 2"},
        # Add more records as needed
    ]

    os.system('touch posted_records.txt')
    posted_records_file = "posted_records.txt"

    # Load posted records from the file if it exists
    posted_records = set()
    if os.path.exists(posted_records_file):
        with open(posted_records_file, "r") as file:
            posted_records.update(map(int, file.read().splitlines()))

    # Process each record
    for record in records:
        record_id = record["id"]
        if record_id not in posted_records:
            # Post the record to the API
            success = post_to_api(record)

            # If successful, update the posted_records set and save it to the file
            if success:
                posted_records.add(record_id)
                with open(posted_records_file, "a") as file:
                    file.write(str(record_id) + "\n")

if __name__ == "__main__":
    main()
