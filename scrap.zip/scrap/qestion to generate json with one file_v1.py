#Instead of generating a new file for each key_value I want all
# the contents of the dictionary with the records in one file name in one file name "records_timestamp".json
# and 'key_value' in another file name "key_value_timestamp.csv" modify the following code to do so 


import json
import time

# Create a filename with timestamp
timestamp = time.strftime("%Y%m%d%H%M%S")
file_name = f"Json_records_{timestamp}.json"

delimiter = chr(31)
timestamp = time.strftime("%Y%m%d%H%M%S")
file_name = f"Json_records_{timestamp}.json"
with open(file_name, "w") as json_file:
   for key_value, records in grouped_records.items():
        # Write each record with a comma after it (except for the last one)
        for i, record in enumerate(records):
            json.dump(record, json_file, indent=2)
            json_file.write(delimiter)
            # Add a newline between records for better readability
            json_file.write('\n')
            
            
 # Create a file for key_value
key_value_file_name = f"Json_Keys_{timestamp}.csv"
with open(key_value_file_name, "w", newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['key_value'])
    for key_value in grouped_records.keys():
        csv_writer.writerow([key_value])
  
  
  
      
### can be in post api script ################/
      
file_name = "Json_records_20240206063104.json" 
delimiter = chr(31)
with open(file_name, "r") as json_file:
    content = json_file.read()

# Split the content based on the delimiter
records = content.split(delimiter)


# Remove empty entries in case there are extra delimiters
records = [record.strip() for record in records if record.strip()]

for i, record in enumerate(records):
    try:
        data = json.loads(record)
        print(f"Record {i + 1}: {data}")
    except json.JSONDecodeError as e:
        print(f"Error decoding record {i + 1}: {e}")
        
        
        
for i, record in enumerate(records):
    try:
        data = json.loads(record)
        print(f"Record {i + 1}: {data}")
    except json.JSONDecodeError as e:
        print(f"Error decoding record {i + 1}: {e}")